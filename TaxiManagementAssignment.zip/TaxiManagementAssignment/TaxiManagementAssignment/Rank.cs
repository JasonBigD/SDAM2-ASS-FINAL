﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaxiManagementAssignment
{
    public class Rank
    {
        public int Id;

        public int TaxiSpacesNum;

        public List<Taxi> TaxiSpace;
        public Rank(int rankid, int taxisspacenum)
        {
            Id = rankid;
            TaxiSpacesNum = taxisspacenum;
            TaxiSpace = new List<Taxi>(TaxiSpacesNum);
        }

        public bool AddTaxi(Taxi t)
        {
            if (TaxiSpacesNum == 0)
            {
                return false;
            }
            else 
            {
                t.Rank = this;
                TaxiSpace.Add(t);
                TaxiSpacesNum--;
                return true;
            }
        }

        public Taxi FrontTaxiTakesFare(string destination, double agreedPrice)
        {
            if (TaxiSpace.Count == 0)
            {
                return null;
            }
            else
            {
                Taxi t = TaxiSpace[0];
                t.AddFare(destination, agreedPrice);
                TaxiSpace.Remove(t);
                TaxiSpacesNum++;
                return t;
            }
            
        }
    }
        
}
