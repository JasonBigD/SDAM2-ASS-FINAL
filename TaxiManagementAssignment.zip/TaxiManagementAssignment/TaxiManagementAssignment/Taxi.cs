﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaxiManagementAssignment
{
    public class Taxi
    {
        public int Number;

        public double CurrentFare;

        public string Destination = "";

        public string Location = ON_ROAD;

        public static string IN_RANK = "in rank";
        public static string ON_ROAD = "on the road";
        private Rank rank;
        public Rank Rank
        {
            get
            {
                return rank;
            }
            set
            {
                if (Destination != "")
                {
                    throw new Exception("Cannot join rank if fare has not been dropped");
                }
                else if (value is null)
                {
                    throw new Exception("Rank cannot be null");
                }
                else
                {
                    rank = value;
                    Location = IN_RANK;
                }
            }
           
        }

        public double TotalMoneyPaid = 0;

        public Taxi(int num)
        {
            Number = num;
            CurrentFare = 0;

        }

        public void AddFare(string destination, double agreedPrice)
        {
            Destination = destination;
            CurrentFare = agreedPrice;
            rank = null;
            Location = ON_ROAD;
        }

        public void DropFare(bool priceWasPaid)
        {
            if (priceWasPaid == false)
            {
                TotalMoneyPaid = 0;
            }
            else
            {
                Destination = "";
                Location = ON_ROAD;
                TotalMoneyPaid = CurrentFare;
                CurrentFare = 0;
            }
        }

    }
}
