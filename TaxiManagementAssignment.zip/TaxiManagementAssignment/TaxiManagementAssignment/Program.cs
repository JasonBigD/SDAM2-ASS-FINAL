﻿using System;

namespace TaxiManagement
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\n\tWrite your Taxi Management application in this project." +
                "\n\n\tFollow the instructions in the assignment specification." +
                "\n\n\tREMEMBER: do not change any of the code in the tests project." +
                "\n\n\tYou can delete the code in the Main() method.\n\n");
        }
    }

}
